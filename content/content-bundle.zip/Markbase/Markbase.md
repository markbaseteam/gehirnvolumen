[markbase.xyz](https://www.markbase.xyz/) ist eine Plattform, auf der jeder mit nur wenigen Schritten seine [[Obsidian]] Notes veröffentlichen kann.

Das ganze ist kostenlos, sofern man damit leben kann, dass die Seiten sich nur jede Stunde aktualisieren lassen.

Hier ist eine Beispielseite, die gleichzeitig die Dokumentation von Markbase ist:
https://docs.markbase.xyz/Home

Markbase befindet sich in stetiger Entwicklung und es fehlen auch noch viele Features, z.B. gibt es zum Zeitpunkt dieser Note noch keine Möglichkeit lokale Bilder aus Obsidian anzuzeigen. Abgesehen von den fehlenden Features, gibt es absolut nichts vergleichbares, dass so einfach zu benutzen ist.

Wer sehen will was aktuell entwickelt wird, wie der Fortschritt ist und vlt. auch selbst einen Feature-Wunsch äußern will, kann das auf deren [öffentlichen Trello-Roadmap](https://trello.com/b/qYaGuz0i/markbase-roadmap) tun.

## Eigenarten

Da sich das Plugin noch in der Entwicklung befindet sollte man sich bei Problemen und/oder Unklarheiten immer auch die [offiziellen aktuellen Infos](https://github.com/markbase-obsidian/obsidian-markbase#optional) einholen ("Optional", "Notes", "Changelog" etc.), beispielsweise wenn es darum geht, wie man das Theme updated o.ä.