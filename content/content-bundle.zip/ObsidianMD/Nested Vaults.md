## Allgemein

Nested Vaults sind einfach gesagt Vaults, innerhalb von Vaults.
Es sind also verschachtelte Vaults, wie der Name schon sagt.

## Vorteile

Durch diese Vault-Struktur sind eine Vielzahl von Möglichkeiten eröffnet, wie z.B.:
- Gesamt-Übersicht über alle Notes in allen Vaults gleichzeitig.
- Vault-spezifische Suche möglich, z.B. nur in einem Child-Vault oder auch global in allen Vaults.
- Getrennte Vaults ermöglichen getrennte Arbeitsbereiche, die man auch entsprechend getrennt mit anderen teilen und bearbeiten kann (nutzt man nur ein geteiltes Vault, kann jeder immer alles oder nichts bearbeiten). So kann man also z.B. einen Vault nur für sich privat behalten und einen anderen für andere zur Zusammenarbeit bereitstellen.
- Getrennte Graphen-Ansicht möglich (Generell beinahe alles, inklusive Einstellungen, getrennt pro Vault möglich).
	- Beispielsweise kann man in der Graphen-Ansicht dann pro Vault alle darunter liegenden Notes als "Gehirn"-Verknüpfungen betrachten.

## Nachteile

- Diese Vorgehensweise ist nicht empfohlen, da sie zu Komplikationen mit z.B. Backlinks führen kann oder Konflikte bei identischen Pfaden/Dateinamen usw., daher rate ich diese Methode ab, wenn man nicht genau weiß, was man tut.
- Die manuelle Konfiguration ist kompliziert, langwierig, fehleranfällig und mühselig, da man alle Vaults separat einstellen muss, inklusive aller Extensions usw. - Wie man seine Vaults einheitlich Konfigurieren kann, ohne alles separat einstellen zu müssen, kann man bei "[[Sync Vault Configuration]]" nachlesen.

## Struktur

Ich habe die folgende Vault-Struktur:

**Super Brain**
	**Schatzkiste**
		private
		public
	**Gehirnvolumen**
		private
		public
	**hmmmmmm**
		private
		public

### Erklärungen

#### Vaults

- Super Brain
	- **Mein Arbeitsbereich - ich öffne immer nur diesen Vault um in allen Vaults gleichzeitig zu arbeiten!**
	- Dies ist das Main-Vault zur Übersicht über absolut alles (=> Mein digitales Gehirn).
	- Um für mich persönlich globale Backlinks verwenden zu können arbeite ich ausschließlich immer von diesem Vault aus! Die Backlinks sollen primär für MICH im Super Brain funktionieren, nicht für die Nested Vaults!
	- DIESES VAULT IST IMMER PRIVAT, DA ES ALLE DARUNTER LIEGENDEN VAULTS MIT SÄMTLICHEN PRIVATEN DATEN ENTHÄLT UND DARF NIEMALS VERÖFFENTLICHT WERDEN!!!
- Schatzkiste
	- Vault für alles zur Arbeit um darin "kruschen" zu können um z.B. hilfreiche Infos für die Arbeit zu finden, inklusive aller arbeitsbezogener Tages-Notes.
- Gehirnvolumen 
	- Vault für alles persönliche, inklusive aller persönlicher Tages-Notes, Random-Notes und Ideen usw.
- hmmmmmm 
	- Vault für meine öffentlichkeits-tauglichen Tutorials/Troubleshoots/Tipps/Erkenntnisse/usw.
	- https://hmmmmmm.markbase.xyz

#### Veröffentlichung

- Eine Veröffentlichung findet NUR aus dem Super Brain Vault statt - NIEMALS aus den Nested Vaults! In den Nested Vaults, sollte nach Möglichkeit auch keine Markbase Extension installiert sein und schon gar nicht mit meinem Token, damit NUR ich veröffentlichen kann, weil NUR ich Zugriff auf das Super Brain habe.
- Alle `public`-Ordner sind in Form einer jeweils eigenen kostenlosen [[Markbase]] Website öffentlich einsehbar.
- Alle `private`-Ordner sind NICHT für die Öffentlichkeit und MÜSSEN privat/offline bzw. in ausschließlich eigenem Zugriff gehalten werden.
- In der Free Version von Markbase ist es nicht möglich öfter als 1 mal pro Stunde zu synchronisieren. D.h. man muss für jeden einzelnen `public`-Ordner den man mit Markbase veröffentlichen will 1 Stunde Warte-Zeit einplanen!

## Hinweise

Beachte die Eigenarten von [[Markbase]] bezüglich Sync etc.

---

TODOs:
- Alle Vaults (public ordner) zu markbase Websites
- Gitlab/Github Versionierung
- Konfiguration dokumentieren mit asset ordner und expansions usw