Notizen:
Ggf. muss dieser Prozess VOR markbase einrichtung erfolgen. (=> Prüfen)

- [ ] TODO-rgnkmlw4 Sync Vault Configuation Doku
- [ ] Ggf. einfach die .obsidian file kopieren und bearbeiten?